#pragma once
#include "Renderer.h"


class Object {
protected:
	float x, y, size;
	float colorR, colorG, colorB, colorA;
public:
	Object();

	Object(float setx, float sety, float setSize, float setRed, float setGreen, float setBlue, float setAlpha);

	float getX() const;

	float getY() const;

	float getSize() const;

	void setX(const float & sx);

	void setY(const float & sy);

	void setSize(const float & sSize);

	void drawObject(Renderer& Rend);


};