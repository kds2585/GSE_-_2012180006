#pragma once

#include "targetver.h"

#include <stdio.h>
#include <tchar.h>
