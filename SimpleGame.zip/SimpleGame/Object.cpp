#include "stdafx.h"
#include "Object.h"


Object::Object() {

}

Object::Object(float setx, float sety, float setSize, float setRed, float setGreen, float setBlue, float setAlpha)
	: x(setx), y(sety), size(setSize), colorR(setRed), colorG(setGreen), colorB(setBlue), colorA(setAlpha)
{

}

float Object::getX() const  {
	return x;
}
float Object::getY() const {
	return y;
}
float Object::getSize() const {
	return size;
}
void Object::setX(const float& sx) {
	x = sx;
}
void Object::setY(const float& sy) {
	y = sy;
}
void Object::setSize(const float& sSize) {
	size = sSize;
}

void Object::drawObject(Renderer& Rend){
	Rend.DrawSolidRect(x, y, 0, size, colorR, colorG, colorB, colorA);
}